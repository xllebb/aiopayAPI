
<p align="center">
  <img src="https://ic.wampi.ru/2023/10/04/LOGO.png" alt="Image"/>
</p>


<h1 align='center'><b> aiopayAPI </b>
<h2 align="center"> Асинхронное API для работы с сайтом Payok.io</h2></h1>


![Static Badge](https://img.shields.io/badge/author-xllebbSQ-blue) ![PyPI - Python Version](https://img.shields.io/pypi/pyversions/aiopayAPI) ![PyPI - Downloads](https://img.shields.io/pypi/dm/aiopayAPI) 
![PyPI - License](https://img.shields.io/pypi/l/aiopayAPI)
-------------------------------

<h1 align="center">Важные ссылки</h1>
<h2 align="center">
  <a href="https://pypi.org/project/aiopayAPI/">PyPi</a>
  <br>
  <a href="https://aiopayapi.readthedocs.io/ru/latest/index.html">Документация</a>
  <br>
  <a href="">GitHub</a>
</h2>


## Возможности
---------------------------------
- Получение баланса
- Получение транзакций
- Создание выплат (переводов)
  - Методы выплат
- Получение выплат
- Создание ссылки для оплаты
- Возможные ошибки







