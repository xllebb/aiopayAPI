class Commission:
    """Комиссия платежа"""

    balance: str  = "balance"
    """Комисия с баланса"""

    payment: str = "payment"
    """Комиссия с платежа"""